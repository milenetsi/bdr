<?php
/*
 * By: Milene Santos Teixeira
 * milene.tsi@gmail.com
 */

class Tarefa
{
    private $id;
    private $titulo;
    private $descricao;
    private $prioridade;
    private $con;

    function __construct($con)
    {
        $this->con = $con;
    }

    function getId()
    {
        return $this->id;
    }

    function getTitulo()
    {
        return $this->titulo;
    }

    function getDescricao()
    {
        return $this->descricao;
    }

    function getPrioridade()
    {
        return $this->prioridade;
    }

    function setId($id)
    {
        $this->id = $id;
    }

    function setTitulo($titulo)
    {
        $this->titulo = $titulo;
    }

    function setDescricao($descricao)
    {
        $this->descricao = $descricao;
    }

    function setPrioridade($prioridade)
    {
        $this->prioridade = $prioridade;
    }

    function cadastrar($titulo, $descricao = "", $prioridade)
    {
        $db = new Database($this->con);

        $valores = array($titulo, $prioridade);
        $colunas = array("titulo", "prioridade");
        if ($descricao != "") {
            array_push($colunas, "descricao");
            array_push($valores, $descricao);
        }

        return $db->insert("tarefa", $colunas, $valores);
    }

    function deletarTarefa()
    {
        $db = new Database($this->con);
        //Exclusao logica
        return $db->update("tarefa", array("deletada"), array("1"), "idtarefa=$this->id");
    }

    function alterarTarefa($novoTitulo = "", $novadescricao = "",
                           $novaPrioridade = "")
    {
        $db = new Database($this->con);

        $valores = array();
        $colunas = array();
        if ($novoTitulo != "") {
            array_push($colunas, "titulo");
            array_push($valores, $novoTitulo);
        }
        if ($novadescricao != "") {
            array_push($colunas, "descricao");
            array_push($valores, $novadescricao);
        }
        if ($novaPrioridade != "") {
            array_push($colunas, "prioridade");
            array_push($valores, $novaPrioridade);
        }

        return $db->update("tarefa", $colunas, $valores, "idtarefa=$this->id");
    }

    function buscaTarefabyId($id)
    {
        $db = new Database($this->con);

        $result = $db->select("tarefa", "", "idtarefa=$id");
        if (mysqli_num_rows($result) > 0) {
            $res = mysqli_fetch_assoc($result);
            $this->setDescricao($res['descricao']);
            $this->setTitulo($res['titulo']);
            $this->setPrioridade($res['prioridade']);
        }
    }
}