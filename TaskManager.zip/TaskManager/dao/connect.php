<?php
/*
 * By: Milene Santos Teixeira
 * milene.tsi@gmail.com
 */

function connect()
{
    $con = mysqli_connect("127.0.0.1", "milene", "1234", "task_manager",
        "3360");

    if (!$con) {
        echo "Error: Unable to connect to MySQL.".PHP_EOL;
        echo "Debugging errno: ".mysqli_connect_errno().PHP_EOL;
        echo "Debugging error: ".mysqli_connect_error().PHP_EOL;
        return $con;
    }

    //echo "Success.";
    //echo "Host information: ".mysqli_get_host_info($con).PHP_EOL;
    return $con;
}
