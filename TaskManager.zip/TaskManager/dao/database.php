<?php
/*
 * By: Milene Santos Teixeira
 * milene.tsi@gmail.com
 */
class Database{
    public $con = false;

    /**
     * Conecta ao BD ao inicializar classe
     */
    function __construct($con)
    {
        $this->con = $con;
    }

    /**
     * Insere na tabela informada por parametro. Retorna id do item inserido
     * @param type $table nome da tabela String
     * @param type $columns nome das colunas array
     * @param type $values valores a serem inseridos array
     */
    public function insert($table, $columns, $values)
    {
        $query = "INSERT INTO $table (";
        $colunas ="";
        foreach ($columns as $row) {
            $colunas .= "$row,";
        }
        //remove ultima virgula
        $colunas = substr($colunas, 0, -1);
        $query .= $colunas;

        $query .= ") VALUES (";

        $vals = "";
        foreach ($values as $value) {
            $vals .= "'$value',";
        }
        //remove ultima virgula
        $vals = substr($vals, 0, -1);
        $query .= $vals;

        $query .= ")";
        mysqli_query($this->con, $query);
        return mysqli_insert_id($this->con);
    }

    /**
     * Atualiza tabela informada por parametro.
     * @param type $table nome da tabela String
     * @param type $columns nome das colunas array
     * @param type $values valores a serem inseridos array
     * @param type $condition (opcional) condicao formato: String coluna=valor
     * @return type falso se erro
     */
    public function update($table, $columns, $values, $condition = "")
    {
        $query = "UPDATE $table SET ";
        $colunas = "";
        for ($i = 0; $i < sizeof($columns); $i++) {
            $colunas .= "$columns[$i]='$values[$i]',";
        }

        //remove ultima virgula
        $colunas = substr($colunas, 0, -1);
        $query .= $colunas;

        if ($condition != "") {
            $query .= " WHERE $condition";
        }
        return mysqli_query($this->con, $query);
    }

    /**
     * Deleta da tabela recebida por parametro, conforme condicao
     * @param type $table nome da tabela
     * @param type $condition condicao formato: String coluna=valor
     * @return type falso se erro
     */
    public function delete($table, $condition)
    {
        $query = "DELETE FROM $table  WHERE $condition";
        return mysqli_query($this->con, $query);
    }

    /**
     * Seleciona itens da tabela recebida por parametro
     * @param type $table nome da tabela
     * @param type $columns colunas a serem selecionadas
     * @param type $condition (opcional) condicao formato: String coluna=valor
     * @param type $order ordenacao
     * @return type
     */
    public function select($table, $columns = "", $condition = "", $order = "")
    {
        $query = "SELECT ";
        if ($columns != "") {
            $query .= "$columns";
        } else {
            $query .= "*";
        }

        $query .= " FROM $table";

        if ($condition != "") {
            $query .= " WHERE $condition";
        }
        if ($order != "") {
            $query .= " ORDER BY $order";
        }

        return mysqli_query($this->con, $query);
    }
}