<?php
/**
 * By: Milene Santos Teixeira
 * milene.tsi@gmail.com
 *
 * Template: https://bootsnipp.com/snippets/featured/admin-lists-panel
 */
require './dao/connect.php';
require './dao/database.php';

$con = connect();
$db  = new Database($con);

$tarefas = array();
$res     = $db->select("tarefa",
    "idtarefa,descricao,titulo,IF(prioridade = '1', 'Alta', IF(prioridade = '2', 'Media', 'Baixa')) as prioridadeTarefa",
    "deletada<>1", "prioridade");
?>
<head>
    <title>Gerenciador de tarefas</title>
    <meta charset="UTF-8">
    <style>
        .trash { color:rgb(209, 91, 71); }
        .flag { color:rgb(248, 148, 6); }
        .panel-body { padding:0px; }
        .panel-footer .pagination { margin: 0; }
        .panel .glyphicon,.list-group-item .glyphicon { margin-right:5px; }
        .panel-body .radio, .checkbox { display:inline-block;margin:0px; }
        .panel-body input[type=checkbox]:checked + label { text-decoration: line-through;color: rgb(128, 144, 160); }
        .list-group-item:hover, a.list-group-item:focus {text-decoration: none;background-color: rgb(245, 245, 245);}
        .list-group { margin-bottom:0px; }

    </style>
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
</head>
<body>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script>

        function apagar(id) {
            $.ajax({
                url: ("./server.php"),
                type: "POST",
                dataType: 'json',
                data: {"idTarefa": id, "action": "delete"},
                success: function (data) {
                    $("#msg").html(data);
                    if (data != "Erro!") {
                        $("#divTarefa" + id).hide();
                    }
                }})
        }
        function editar(id, titulo, prioridade, descricao) {
            $.ajax({
                url: ("./server.php"),
                type: "POST",
                data: {"idTarefa": id, "action": "editar", "titulo": titulo, "prioridade": prioridade, "descricao": descricao},
                success: function (data) {//<<tem q ajuastar pra atualizar modal edit tbm
                    var prior = "Alta";
                    if (prioridade == "2") {
                        prior = "Media";
                    } else if (prioridade == "3") {
                        prior = "Baixa";
                    }
                    $("#msgEdit").html(data);
                    $("#prioridade" + id).html(prior);
                    $("#titulo" + id).html(titulo);
                }})
        }
        function cadastrar(titulo, prioridade, descricao) {
            $.ajax({
                url: ("./server.php"),
                type: "POST",
                data: {"action": "insere", "titulo": titulo, "prioridade": prioridade, "descricao": descricao},
                success: function (data) {
                    var msg = data;
                    if (data != "Erro!") {
                        msg+=" Atualize a pagina para ve-la na lista!"; //Eu sei, poderia ter feito isto automatico. Mas faltou tempo
                    }

                    $("#msgNova").html(msg);
                }})
        }

        function painelEditar(id, titulo, prioridade, descricao) {
            $("#idedit").html(id);
            $("#idTarefaE").val(id);
            $("#tituloE").val(titulo);
            $("#descricaoE").val(descricao);

            var prior = 1;
            if (prioridade == "Media") {
                prior = 2;
            } else if (prioridade == "Baixa") {
                prior = 3;
            }
            $("#prioE").val(prior);
        }

        function exibirDetalhes(titulo, prioridade, descricao) {
            $("#tituloTask").html(titulo);
            $("#prioridadeTask").html(prioridade);
            $("#descricaoTask").html(descricao);
        }


    </script>


   <div id="modalNew" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content" id="newDiv">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Nova tarefa</h4><div id="msgNova" style="font-weight: bold;color: blue;"></div>
                </div>
                <div class="modal-body">
                    <label for="tituloN">Titulo:</label>
                    <input type="text" class="form-control" id="tituloN" aria-describedby="a" placeholder="nome da tarefa">
                    <label for="descricaoN">Descricao:</label>
                    <input type="text" class="form-control" id="descricaoN" aria-describedby="b" placeholder="detalhes...">
                    <label for="prioN">Prioridade (1:Alta, 2:Media, 3:Baixa):</label>
                    <input type="number" class="form-control" id="prioN" aria-describedby="c" placeholder="prioridade">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" onclick='cadastrar($("#tituloN").val(), $("#prioN").val(), $("#descricaoN").val());'>Salvar</button>
                    <button type="button" class="btn btn-warning" data-dismiss="modal">Cancelar</button>
                </div>
            </div>
        </div>
    </div>

    <div id="modalEdit" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content" id="editDiv">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Editando tarefa <div id="idedit"></div><div id="msgEdit" style="font-weight: bold;color: blue;"></div></h4>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="idTarefaE" value=""/>
                    <label for="tituloE">Titulo:</label>
                    <input type="text" class="form-control" id="tituloE" aria-describedby="a" placeholder="nome da tarefa">
                    <label for="descricaoE">Descricao:</label>
                    <input type="text" class="form-control" id="descricaoE" aria-describedby="b" placeholder="detalhes...">
                    <label for="prioE">Prioridade (1:Alta, 2:Media, 3:Baixa):</label>
                    <input type="number" class="form-control" id="prioE" aria-describedby="c" placeholder="prioridade">
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-success" onclick='editar($("#idTarefaE").val(), $("#tituloE").val(), $("#prioE").val(), $("#descricaoE").val());'>Salvar</button>
                    <button type="button" class="btn btn-warning" data-dismiss="modal">Cancelar</button>
                </div>
            </div>
        </div>
    </div>

    <div id="modalTask" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <!-- Modal content-->
            <div class="modal-content" id="seeTask">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Detalhes da tarefa</h4>
                </div>
                <div class="modal-body">
                    <label for="tituloTask">Titulo:</label><div id="tituloTask"></div>
                    <label for="descricaoTask">Descricao:</label><div id="descricaoTask"></div>
                    <label for="prioridadeTask">Prioridade:</label><div id="prioridadeTask"></div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <span class="glyphicon glyphicon-list"></span>Lista de tarefas
                        <div class="pull-right action-buttons">
                            <div class="btn-group pull-right">
                                <button type="button" class="btn btn-default btn-xs dropdown-toggle" data-toggle="dropdown">
                                    <span class="glyphicon glyphicon-cog" style="margin-right: 0px;"></span>
                                </button>
                                <ul class="dropdown-menu slidedown">
                                    <li><span class="glyphicon glyphicon-pencil"></span>Editar</li>
                                    <li><span class="glyphicon glyphicon-trash"></span>Apagar</li>
                                    <li><span class="glyphicon glyphicon-flag"></span>Detalhes</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="panel-body">
                        <div id="msg" class="col-md-8"></div>
                        <div style="cursor: pointer;"  data-toggle="modal" data-target="#modalNew" ><span class="glyphicon glyphicon-plus"></span>Nova</div>
                        <ul class="list-group" id="listaTarefas">
                            <li class="list-group-item">
                                <div class="checkbox col-md-11">
                                    <div class="col-md-4" style="font-weight: bold;font-size: 15pt;">
                                        Prioridade
                                    </div>
                                    <div style="font-weight: bold;font-size: 15pt;">
                                        Titulo
                                    </div>
                                </div>
                                <div style="font-weight: bold;font-size: 15pt;">
                                    Ação
                                </div>
                            </li>
                            <?php
                            if (mysqli_num_rows($res) > 0) {
                                while ($result = mysqli_fetch_assoc($res)) {
                                    ?>
                                    <li class="list-group-item" id="divTarefa<?= $result['idtarefa'] ?>">
                                        <div class="checkbox col-md-10">
                                            <div class="col-md-4" >
                                                <label id="prioridade<?= $result['idtarefa'] ?>">
                                                    <?= $result['prioridadeTarefa'] ?>
                                                </label></div>
                                            <label id="titulo<?= $result['idtarefa'] ?>">
                                                <?= $result['titulo'] ?>
                                            </label>
                                        </div>
                                        <div class="action-buttons">
                                            <div style="cursor: pointer;" data-toggle="modal" data-target="#modalEdit" onclick="painelEditar(<?= "'".$result['idtarefa']."','".$result['titulo']."','".$result['prioridadeTarefa']."','".$result['descricao']."'" ?>);"><span class="glyphicon glyphicon-pencil"></span></div>
                                            <div style="cursor: pointer;" class="trash" onclick="apagar(<?= "'".$result['idtarefa']."'" ?>);"><span class="glyphicon glyphicon-trash"></span></div>
                                            <div style="cursor: pointer;" data-toggle="modal" data-target="#modalTask" class="flag" onclick="exibirDetalhes(<?= "'".$result['titulo']."','".$result['prioridadeTarefa']."','".$result['descricao']."'" ?>);"><span class="glyphicon glyphicon-flag"></span></div>
                                        </div>
                                    </li>
                                    <?php
                                }
                            } else {
                                ?>
                                <li>Sem tarefas!</li>
                            <?php }
                            ?>
                        </ul>
                    </div>
                    <div class="panel-footer">
                        <div class="row">
                            <div class="col-md-6">
                                <h6>
                                    Total de tarefas <span class="label label-info"><?= mysqli_num_rows($res) ?></span></h6>
                            </div>
                            <div class="col-md-6">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-2"></div>
        </div>
    </div>
</body>