<?php
/*
 * By: Milene Santos Teixeira
 * milene.tsi@gmail.com
 */

header("Content-Type:application/json");

require './dao/connect.php';
require './dao/database.php';
require 'Tarefa.php';

if (isset($_POST['action'])) {

    $con = connect();
    if ($_POST['action'] == "delete") {
        $tar = new Tarefa($con);
        $tar->setId($_POST['idTarefa']);
        if ($tar->deletarTarefa()) {
            echo json_encode("Tarefa deletada");
        } else {
            echo json_encode("Erro!");
        }
    } elseif ($_POST['action'] == "insere") {
        $tar = new Tarefa($con);
        if ($tar->cadastrar($_POST['titulo'], $_POST['descricao'],
                $_POST['prioridade'])) {
            echo json_encode("Tarefa cadastrada!");
        } else {
            echo json_encode("Erro!");
        }
    } elseif ($_POST['action'] == "editar") {
        $tar = new Tarefa($con);        
        $tar->setId($_POST['idTarefa']);
        if ($tar->alterarTarefa($_POST['titulo'], $_POST['descricao'],
                $_POST['prioridade'])) {
            echo json_encode("Tarefa alterada!");
        } else {
            echo json_encode("Erro!");
        }
    }
}

